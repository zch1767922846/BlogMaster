import sys
import json
import threading
import socket
from datetime import datetime
from PyQt5.QtWidgets import (QApplication, QWidget, QLabel, QLineEdit, QPushButton,
                             QVBoxLayout, QHBoxLayout, QMessageBox, QMainWindow,
                             QListWidget, QTextEdit, QInputDialog, QListWidgetItem,
                             QGroupBox, QSplitter, QFrame, QScrollArea, QSizePolicy)
from PyQt5.QtCore import pyqtSignal, QObject, Qt, QSize
from PyQt5.QtGui import QColor, QFont, QIcon, QTextCursor, QPalette, QBrush, QPixmap

# 导入Coze SDK
from cozepy import COZE_CN_BASE_URL
from cozepy import Coze, TokenAuth, Message, ChatEventType  # noqa


# 自定义信号类：新增群聊相关信号
class MsgSignal(QObject):
    new_msg = pyqtSignal(str)  # 接收新消息的信号
    error_msg = pyqtSignal(str)  # 接收错误信息的信号
    add_friend_err = pyqtSignal(str)  # 添加好友错误信号
    status_update = pyqtSignal(str, bool)  # 好友状态更新信号
    group_update = pyqtSignal(dict)  # 群聊列表更新信号（新增群信息）
    ai_response = pyqtSignal(str)  # AI响应信号


class LoginWindow(QWidget):
    """登录/注册界面"""

    def __init__(self):
        super().__init__()
        self.setWindowTitle("即时通讯 - 登录")
        self.setFixedSize(720, 360)
        self.client_socket = None
        self.init_ui()
        self.init_socket()  # 初始化socket（带超时）

    def init_ui(self):
        # 设置整体样式
        self.setStyleSheet("""
            QWidget {
                background-color: #f0f2f5;
                font-family: 'Microsoft YaHei', sans-serif;
            }
            QLabel#titleLabel {
                font-size: 24px;
                font-weight: bold;
                color: #1a73e8;
                margin-bottom: 30px;
            }
            QLabel {
                font-size: 16px;
                color: #0958d9;
            }
            QLineEdit {
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
                font-size: 16px;
                background-color: white;
            }
            QLineEdit:focus {
                border-color: #1a73e8;
                outline: none;
            }
            QPushButton {
                padding: 8px;
                border-radius: 4px;
                font-size: 16px;
                font-weight: 500;
            }
            QPushButton#loginBtn {
                background-color: #1a73e8;
                color: white;
                border: none;
            }
            QPushButton#loginBtn:hover {
                background-color: #1765cc;
            }
            QPushButton#registerBtn {
                background-color: white;
                color: #1a73e8;
                border: 1px solid #1a73e8;
            }
            QPushButton#registerBtn:hover {
                background-color: #f0f7ff;
            }
        """)

        # 主布局
        main_layout = QVBoxLayout()
        main_layout.setContentsMargins(50, 50, 50, 50)
        main_layout.setSpacing(15)

        # 标题
        title_label = QLabel("即时通讯")
        title_label.setObjectName("titleLabel")
        title_label.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(title_label)

        # 用户名行
        user_layout = QHBoxLayout()
        user_layout.setSpacing(10)
        self.user_label = QLabel("用户名：")
        self.user_edit = QLineEdit()
        self.user_edit.setPlaceholderText("请输入用户名")
        user_layout.addWidget(self.user_label)
        user_layout.addWidget(self.user_edit)
        main_layout.addLayout(user_layout)

        # 密码行
        pwd_layout = QHBoxLayout()
        pwd_layout.setSpacing(10)
        self.pwd_label = QLabel("密码：")
        self.pwd_edit = QLineEdit()
        self.pwd_edit.setEchoMode(QLineEdit.Password)
        self.pwd_edit.setPlaceholderText("请输入密码")
        pwd_layout.addWidget(self.pwd_label)
        pwd_layout.addWidget(self.pwd_edit)
        main_layout.addLayout(pwd_layout)

        # 按钮行
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(15)
        self.login_btn = QPushButton("登录")
        self.login_btn.setObjectName("loginBtn")
        self.register_btn = QPushButton("注册")
        self.register_btn.setObjectName("registerBtn")
        # 设置按钮固定高度
        self.login_btn.setMinimumHeight(30)
        self.register_btn.setMinimumHeight(30)
        btn_layout.addWidget(self.login_btn)
        btn_layout.addWidget(self.register_btn)
        main_layout.addLayout(btn_layout)

        self.setLayout(main_layout)

        # 绑定事件
        self.login_btn.clicked.connect(self.login)
        self.register_btn.clicked.connect(self.register)

    def init_socket(self):
        """初始化socket，设置超时（避免connect卡住）"""
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.client_socket.settimeout(5)  # 连接超时5秒
        try:
            self.client_socket.connect(('127.0.0.1', 5555))
            self.client_socket.settimeout(None)  # 连接成功后取消超时
        except socket.timeout:
            QMessageBox.critical(self, "错误", "连接服务器超时！请检查服务器是否启动。")
            sys.exit()
        except ConnectionRefusedError:
            QMessageBox.critical(self, "错误", "服务器拒绝连接！请确认服务器已启动。")
            sys.exit()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"连接失败：{str(e)}")
            sys.exit()

    def register(self):
        """处理注册（添加超时和异常捕获）"""
        user = self.user_edit.text().strip()
        pwd = self.pwd_edit.text().strip()
        if not user or not pwd:
            QMessageBox.warning(self, "提示", "用户名/密码不能为空！")
            return

        try:
            msg = json.dumps({"type": "register", "username": user, "password": pwd}).encode('utf-8')
            self.client_socket.send(msg)
            self.client_socket.settimeout(3)
            resp = self.client_socket.recv(1024).decode('utf-8')
            self.client_socket.settimeout(None)
            resp = json.loads(resp)
            QMessageBox.information(self, "结果", resp['msg'])
        except socket.timeout:
            QMessageBox.warning(self, "错误", "服务器无响应，请重试！")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"注册失败：{str(e)}")

    def login(self):
        """处理登录（新增：传入群列表）"""
        user = self.user_edit.text().strip()
        pwd = self.pwd_edit.text().strip()
        if not user or not pwd:
            QMessageBox.warning(self, "提示", "用户名/密码不能为空！")
            return

        try:
            msg = json.dumps({"type": "login", "username": user, "password": pwd}).encode('utf-8')
            self.client_socket.send(msg)
            self.client_socket.settimeout(3)
            resp = self.client_socket.recv(1024).decode('utf-8')
            self.client_socket.settimeout(None)
            resp = json.loads(resp)
            if resp['success']:
                # 登录成功，打开主界面（传入群列表）
                self.main_win = MainWindow(
                    self.client_socket,
                    user,
                    resp['friends'],
                    resp['friend_status'],
                    resp['offline_msgs'],
                    resp['user_groups']  # 传入用户加入的群列表
                )
                self.main_win.show()
                self.close()
            else:
                QMessageBox.warning(self, "失败", resp['msg'])
        except socket.timeout:
            QMessageBox.warning(self, "错误", "服务器无响应，请重试！")
        except Exception as e:
            QMessageBox.warning(self, "错误", f"登录失败：{str(e)}")


class MainWindow(QMainWindow):
    """主聊天界面（优化UI）"""

    def __init__(self, client_socket, username, friends, friend_status, offline_msgs, user_groups):
        super().__init__()
        self.setWindowTitle(f"即时通讯 - {username}")
        self.resize(1000, 700)  # 更大的初始窗口
        self.client_socket = client_socket
        self.username = username
        self.current_target = None  # 当前聊天对象（好友名/群ID）
        self.current_target_type = None  # 类型："friend" 或 "group" 或 "ai"
        self.friend_status = friend_status  # 好友状态：{好友名: 在线状态}
        self.user_groups = {}  # 群聊字典：{group_id: group_name}（方便快速查找）
        for group in user_groups:
            self.user_groups[group['group_id']] = group['group_name']

        # 初始化AI客户端（保持原有逻辑）
        self.init_ai_client()

        # 信号实例
        self.msg_signal = MsgSignal()
        self.msg_signal.new_msg.connect(self.update_msg_display)
        self.msg_signal.error_msg.connect(self.show_error)
        self.msg_signal.add_friend_err.connect(self.show_add_friend_err)
        self.msg_signal.status_update.connect(self.refresh_friend_status)
        self.msg_signal.group_update.connect(self.add_group_to_list)  # 绑定群聊更新
        self.msg_signal.ai_response.connect(self.handle_ai_response)

        # 设置全局样式
        self.setStyleSheet("""
            QMainWindow {
                background-color: #f5f5f5;
            }
            QGroupBox {
                border: 1px solid #ddd;
                border-radius: 6px;
                margin-top: 10px;
                background-color: white;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
                color: #0958d9;
            }
            QListWidget {
                border: none;
                background-color: transparent;
                padding: 5px;
            }
            QListWidget::item {
                padding: 8px 10px;
                border-radius: 4px;
                margin-bottom: 2px;
                color: #333;
            }
            QListWidget::item:selected {
                background-color: #e8f0fe;
                color: #1a73e8;
            }
            QListWidget::item:hover {
                background-color: #f1f3f4;
            }
            QTextEdit {
                border: 1px solid #ddd;
                border-radius: 6px;
                padding: 10px;
                background-color: white;
                font-family: 'Microsoft YaHei', sans-serif;
                font-size: 20px;
            }
            QLineEdit {
                padding: 10px;
                border: 1px solid #ddd;
                border-radius: 6px;
                font-size: 16px;
            }
            QLineEdit:focus {
                border-color: #1a73e8;
                outline: none;
            }
            QPushButton {
                padding: 10px 15px;
                border-radius: 6px;
                font-size: 16px;
                font-weight: 500;
                border: none;
            }
            QPushButton#sendBtn {
                background-color: #1a73e8;
                color: white;
            }
            QPushButton#sendBtn:hover {
                background-color: #1765cc;
            }
            QPushButton#functionBtn {
                background-color: #f1f3f4;
                color: #333;
            }
            QPushButton#functionBtn:hover {
                background-color: #e8eaed;
            }
            .online-status {
                color: #0f9d58;
            }
            .offline-status {
                color: #9aa0a6;
            }
        """)

        # 创建中心部件
        central = QWidget()
        self.setCentralWidget(central)

        # 主布局使用分割器，允许用户调整左右比例
        main_splitter = QSplitter(Qt.Horizontal)
        main_layout = QHBoxLayout(central)
        main_layout.addWidget(main_splitter)

        # 左侧：好友列表 + 群聊列表 + AI列表 + 功能按钮
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(10, 10, 10, 10)
        left_layout.setSpacing(10)

        # 好友分组
        friend_group = QGroupBox("好友列表")
        friend_group.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        friend_layout = QVBoxLayout(friend_group)
        self.friend_list = QListWidget()
        self.friend_list.setAlternatingRowColors(True)  # 交替行颜色
        self.init_friend_list()
        friend_layout.addWidget(self.friend_list)

        # 群聊分组
        group_group = QGroupBox("群聊列表")
        group_group.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        group_layout = QVBoxLayout(group_group)
        self.group_list = QListWidget()
        self.group_list.setAlternatingRowColors(True)
        self.init_group_list()
        group_layout.addWidget(self.group_list)

        # AI机器人分组
        ai_group = QGroupBox("AI助手")
        ai_group.setFont(QFont("Microsoft YaHei", 10, QFont.Bold))
        ai_layout = QVBoxLayout(ai_group)
        self.ai_list = QListWidget()
        self.ai_list.setAlternatingRowColors(True)
        self.init_ai_list()  # 初始化AI列表
        ai_layout.addWidget(self.ai_list)

        # 功能按钮（添加好友、创建群聊、加入群聊）
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(5)
        self.add_friend_btn = QPushButton("添加好友")
        self.add_friend_btn.setObjectName("functionBtn")
        self.create_group_btn = QPushButton("创建群聊")
        self.create_group_btn.setObjectName("functionBtn")
        self.join_group_btn = QPushButton("加入群聊")
        self.join_group_btn.setObjectName("functionBtn")

        # 设置按钮大小策略
        for btn in [self.add_friend_btn, self.create_group_btn, self.join_group_btn]:
            btn.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

        btn_layout.addWidget(self.add_friend_btn)
        btn_layout.addWidget(self.create_group_btn)
        btn_layout.addWidget(self.join_group_btn)

        # 左侧布局组装
        left_layout.addWidget(friend_group, 3)
        left_layout.addWidget(group_group, 3)
        left_layout.addWidget(ai_group, 2)
        left_layout.addLayout(btn_layout, 1)

        # 右侧：聊天窗口
        right_panel = QWidget()
        chat_layout = QVBoxLayout(right_panel)
        chat_layout.setContentsMargins(10, 10, 10, 10)
        chat_layout.setSpacing(10)

        # 聊天标题栏（显示当前聊天对象）
        self.chat_title = QLabel("请选择聊天对象")
        self.chat_title.setFont(QFont("Microsoft YaHei", 12, QFont.Bold))
        self.chat_title.setStyleSheet("color: #333; padding: 5px;")
        chat_layout.addWidget(self.chat_title)

        # 聊天内容区域
        self.msg_display = QTextEdit()
        self.msg_display.setReadOnly(True)
        self.msg_display.setUndoRedoEnabled(False)  # 禁用撤销/重做
        chat_layout.addWidget(self.msg_display)

        # 输入区域
        input_layout = QHBoxLayout()
        input_layout.setSpacing(10)
        self.msg_input = QLineEdit()
        self.msg_input.setPlaceholderText("请输入消息...")
        self.send_btn = QPushButton("发送")
        self.send_btn.setObjectName("sendBtn")
        self.send_btn.setEnabled(False)  # 未选择聊天对象时禁用发送按钮

        # 设置输入框拉伸策略
        input_layout.addWidget(self.msg_input, 7)
        input_layout.addWidget(self.send_btn, 1)
        chat_layout.addLayout(input_layout)

        # 添加到分割器
        main_splitter.addWidget(left_panel)
        main_splitter.addWidget(right_panel)
        main_splitter.setSizes([300, 700])  # 设置初始大小比例

        # 绑定事件
        self.friend_list.itemClicked.connect(self.select_friend_target)
        self.group_list.itemClicked.connect(self.select_group_target)
        self.ai_list.itemClicked.connect(self.select_ai_target)  # AI选择事件
        self.send_btn.clicked.connect(self.send_msg)
        self.msg_input.returnPressed.connect(self.send_msg)
        self.add_friend_btn.clicked.connect(self.add_friend)
        self.create_group_btn.clicked.connect(self.create_group)
        self.join_group_btn.clicked.connect(self.join_group)
        self.msg_input.textChanged.connect(self.toggle_send_button)

        # 显示离线消息
        self.show_offline_msgs(offline_msgs)

        # 启动消息接收线程（修复：替换为正确的方法调用）
        self.start_receive_thread()

    def toggle_send_button(self):
        """根据输入内容和是否选择聊天对象切换发送按钮状态"""
        has_content = len(self.msg_input.text().strip()) > 0
        has_target = self.current_target is not None
        self.send_btn.setEnabled(has_content and has_target)

    def init_ai_client(self):
        """初始化AI客户端"""
        try:
            self.coze_api_token = 'pat_bwIjP0gn2qPHu5Jq3VB2pbiGIvifzkaeWOOVULFKwiiejZdgNcRG57a6EpY6xeIT'
            self.coze_api_base = COZE_CN_BASE_URL
            self.bot_id = '7578364621183238198'
            self.coze = Coze(
                auth=TokenAuth(token=self.coze_api_token),
                base_url=self.coze_api_base
            )
        except Exception as e:
            self.show_error(f"AI助手初始化失败: {str(e)}")
            self.coze = None

    def init_ai_list(self):
        """初始化AI列表"""
        self.ai_list.clear()
        ai_item = QListWidgetItem("智能聊天助手")
        ai_item.setForeground(QColor("blue"))
        ai_item.setData(Qt.UserRole, "ai_assistant")
        self.ai_list.addItem(ai_item)

    def init_friend_list(self):
        """初始化好友列表（带在线状态）"""
        self.friend_list.clear()
        for friend in self.friend_status:
            self.add_friend_item(friend, self.friend_status[friend])

    def add_friend_item(self, friend_name, is_online):
        """添加单个好友项（带状态标记）"""
        status_text = "【在线】" if is_online else "【离线】"
        item_text = f"{friend_name} {status_text}"
        item = QListWidgetItem(item_text)
        item.setForeground(QColor(34, 139, 34) if is_online else QColor(128, 128, 128))
        self.friend_list.addItem(item)

    def init_group_list(self):
        """初始化群聊列表"""
        self.group_list.clear()
        for group_id, group_name in self.user_groups.items():
            self.add_group_item(group_id, group_name)

    def add_group_item(self, group_id, group_name):
        """添加单个群聊项（显示群名称+群ID）"""
        item_text = f"{group_name} (群ID：{group_id})"
        item = QListWidgetItem(item_text)
        item.setForeground(QColor(255, 140, 0))  # 橙色区分群聊
        self.group_list.addItem(item)

    def refresh_friend_status(self, friend_name, is_online):
        """刷新好友在线状态"""
        self.friend_status[friend_name] = is_online
        for i in range(self.friend_list.count()):
            item = self.friend_list.item(i)
            if friend_name in item.text():
                status_text = "【在线】" if is_online else "【离线】"
                item.setText(f"{friend_name} {status_text}")
                item.setForeground(QColor(34, 139, 34) if is_online else QColor(128, 128, 128))
                break

    def add_group_to_list(self, group_info):
        """新增群聊到列表（响应创建/加入群聊）"""
        group_id = group_info['group_id']
        group_name = group_info['group_name']
        self.user_groups[group_id] = group_name
        self.add_group_item(group_id, group_name)

    def show_offline_msgs(self, offline_msgs):
        """展示离线消息"""
        if offline_msgs:
            self.msg_display.append("=== 离线消息 ===")
            for msg in offline_msgs:
                self.msg_display.append(f"[{msg['time']}] {msg['sender']}: {msg['content']}")
            self.msg_display.append("================")

    def select_friend_target(self, item):
        """选择好友聊天对象"""
        friend_name = item.text().split()[0]
        self.current_target = friend_name
        self.current_target_type = "friend"
        self.setWindowTitle(f"即时通讯 - {self.username} 与 {friend_name}聊天")
        self.chat_title.setText(f"与 {self.current_target} 聊天中")
        self.update_msg_display(f"========== 我与{friend_name}的聊天 ==========")
        self.toggle_send_button()

    def select_group_target(self, item):
        """选择群聊对象（提取群ID）"""
        # 从“群名称 (群ID：123)”中提取群ID
        group_id_str = item.text().split("：")[-1].strip(")")
        self.current_target = int(group_id_str)  # 群ID存为整数
        self.current_target_type = "group"
        group_name = item.text().split(" (")[0]
        self.setWindowTitle(f"即时通讯 - {group_name} (群聊)")
        self.chat_title.setText(f"群聊：{group_name}")
        self.update_msg_display(f"========== 群聊：{group_name} ==========")
        self.toggle_send_button()

    def select_ai_target(self, item):
        """选择AI聊天对象"""
        ai_id = item.data(Qt.UserRole)
        self.current_target = ai_id
        self.current_target_type = "ai"
        self.setWindowTitle(f"即时通讯 - {self.username} 与 AI助手 聊天中")
        self.chat_title.setText(f"AI助手：智能助手")
        # self.msg_display.clear()
        self.update_msg_display("========== AI助手 ==========")
        self.update_msg_display("您好！我是您的专属AI助手，有什么可以帮助您的吗？")
        self.toggle_send_button()

    def send_msg(self):
        """发送消息（区分单聊/群聊/AI）"""
        content = self.msg_input.text().strip()
        if not content:
            return
        if not self.current_target:
            QMessageBox.warning(self, "提示", "请先选择聊天对象（好友/群聊/AI助手）！")
            return

        try:
            time_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            if self.current_target_type == "friend":
                # 单聊消息
                msg = {
                    "type": "single_msg",
                    "sender": self.username,
                    "receiver": self.current_target,
                    "content": content,
                    "time": time_str
                }
                self.client_socket.send(json.dumps(msg).encode('utf-8'))
                self.update_msg_display(f"[{time_str}] 我: {content}")
            elif self.current_target_type == "group":
                # 群聊消息
                msg = {
                    "type": "group_chat_msg",
                    "sender": self.username,
                    "group_id": self.current_target,
                    "content": content,
                    "time": time_str
                }
                self.client_socket.send(json.dumps(msg).encode('utf-8'))
                group_name = self.user_groups[self.current_target]
                self.update_msg_display(f"[群聊][{group_name}][{time_str}] 我: {content}")
            elif self.current_target_type == "ai":
                # AI聊天消息
                self.update_msg_display(f"[{time_str}] 我: {content}")
                # 先显示AI助手的前缀，后续追加内容
                self.ai_response_prefix = f"[{time_str}] AI助手: "
                self.msg_display.append(self.ai_response_prefix)
                # 保存光标位置，用于后续追加AI回复
                self.ai_cursor = self.msg_display.textCursor()
                self.ai_cursor.movePosition(self.ai_cursor.End)
                self.msg_input.clear()

                # 启动AI请求线程
                threading.Thread(
                    target=self.send_ai_request,
                    args=(content,),
                    daemon=True
                ).start()
            self.msg_input.clear()
        except Exception as e:
            QMessageBox.warning(self, "错误", f"发送失败：{str(e)}")

    def send_ai_request(self, content):
        """发送请求给AI助手"""
        if not self.coze:
            self.msg_signal.ai_response.emit("AI助手初始化失败，请检查配置")
            return

        try:
            # 使用当前用户名作为user_id，确保每个用户有独立对话上下文
            response_content = ""
            for event in self.coze.chat.stream(
                    bot_id=self.bot_id,
                    user_id=self.username,  # 用用户名作为用户标识
                    additional_messages=[
                        Message.build_user_question_text(content),
                    ],
            ):
                if event.event == ChatEventType.CONVERSATION_MESSAGE_DELTA:
                    response_content += event.message.content
                    # 实时发送响应内容到UI
                    self.msg_signal.ai_response.emit(event.message.content)
            # 响应结束后换行
            self.msg_signal.ai_response.emit("\n")
        except Exception as e:
            self.msg_signal.ai_response.emit(f"\nAI请求失败: {str(e)}")

    def handle_ai_response(self, content):
        """处理AI响应内容（追加显示）"""
        # 将光标移到AI回复前缀的末尾
        cursor = self.msg_display.textCursor()
        cursor.movePosition(cursor.End)
        self.msg_display.setTextCursor(cursor)
        # 追加AI回复内容
        self.msg_display.insertPlainText(content)
        # 保持光标在最后
        self.msg_display.moveCursor(self.msg_display.textCursor().End)

    def update_msg_display(self, text):
        """更新消息显示（通用方法，无额外参数）"""
        self.msg_display.append(text)
        self.msg_display.moveCursor(self.msg_display.textCursor().End)

    def add_friend(self):
        """添加好友（不变）"""
        friend_name, ok = QInputDialog.getText(self, "添加好友", "输入好友用户名：")
        if ok and friend_name.strip():
            friend_name = friend_name.strip()
            try:
                msg = json.dumps({
                    "type": "add_friend",
                    "username": self.username,
                    "friend_username": friend_name
                }).encode('utf-8')
                self.client_socket.send(msg)
                self.client_socket.settimeout(3)
                resp_data = self.client_socket.recv(1024).decode('utf-8')
                self.client_socket.settimeout(None)
                if not resp_data:
                    self.msg_signal.add_friend_err.emit("服务器未返回响应，请重试")
                    return
                try:
                    resp = json.loads(resp_data)
                except json.JSONDecodeError:
                    self.msg_signal.add_friend_err.emit("服务器响应格式错误")
                    return
                QMessageBox.information(self, "结果", resp['msg'])
                if resp['success']:
                    friend_is_online = resp.get('friend_status', False)
                    self.friend_status[friend_name] = friend_is_online
                    self.add_friend_item(friend_name, friend_is_online)
            except socket.timeout:
                self.msg_signal.add_friend_err.emit("连接服务器超时，请重试")
            except socket.error as e:
                self.msg_signal.add_friend_err.emit(f"网络错误：{str(e)}")
            except Exception as e:
                self.msg_signal.add_friend_err.emit(f"添加失败：{str(e)}")

    def create_group(self):
        """创建群聊"""
        group_name, ok = QInputDialog.getText(self, "创建群聊", "输入群聊名称：")
        if ok and group_name.strip():
            group_name = group_name.strip()
            try:
                msg = json.dumps({
                    "type": "create_group",
                    "username": self.username,
                    "group_name": group_name
                }).encode('utf-8')
                self.client_socket.send(msg)
                self.client_socket.settimeout(3)
                resp_data = self.client_socket.recv(1024).decode('utf-8')
                self.client_socket.settimeout(None)
                resp = json.loads(resp_data)
                QMessageBox.information(self, "创建结果", resp['msg'])
                if resp['success']:
                    # 新增群聊到列表
                    self.msg_signal.group_update.emit(resp['group_info'])
            except socket.timeout:
                QMessageBox.warning(self, "错误", "服务器无响应，请重试")
            except Exception as e:
                QMessageBox.warning(self, "错误", f"创建失败：{str(e)}")

    def join_group(self):
        """加入群聊（通过群ID）"""
        group_id, ok = QInputDialog.getText(self, "加入群聊", "输入群ID：")
        if ok and group_id.strip():
            try:
                msg = json.dumps({
                    "type": "join_group",
                    "username": self.username,
                    "group_id": group_id.strip()
                }).encode('utf-8')
                self.client_socket.send(msg)
                self.client_socket.settimeout(3)
                resp_data = self.client_socket.recv(1024).decode('utf-8')
                self.client_socket.settimeout(None)
                resp = json.loads(resp_data)
                QMessageBox.information(self, "加入结果", resp['msg'])
                if resp['success']:
                    # 新增群聊到列表
                    self.msg_signal.group_update.emit(resp['group_info'])
            except socket.timeout:
                QMessageBox.warning(self, "错误", "服务器无响应，请重试")
            except Exception as e:
                QMessageBox.warning(self, "错误", f"加入失败：{str(e)}")

    def listen_msg(self):
        """监听服务器消息（新增群聊消息处理）"""
        while True:
            try:
                data = self.client_socket.recv(1024).decode('utf-8')
                if not data:
                    self.msg_signal.error_msg.emit("与服务器断开连接！")
                    break
                msg = json.loads(data)
                if msg['type'] == 'single_msg':
                    # 单聊消息
                    self.msg_signal.new_msg.emit(f"[{msg['time']}] {msg['sender']}: {msg['content']}")
                elif msg['type'] == 'group_chat_msg':
                    # 群聊消息（标注群名称）
                    group_name = msg['group_name']
                    self.msg_signal.new_msg.emit(
                        f"[群聊][{group_name}][{msg['time']}] {msg['sender']}: {msg['content']}")
                elif msg['type'] == 'status_update':
                    # 好友状态更新
                    self.msg_signal.status_update.emit(msg['username'], msg['status'])
                elif msg['type'] == 'group_msg_result':
                    # 群消息发送失败响应
                    QMessageBox.warning(self, "群消息失败", msg['msg'])
            except socket.error as e:
                self.msg_signal.error_msg.emit(f"网络错误：{str(e)}")
                break
            except json.JSONDecodeError:
                self.msg_signal.error_msg.emit("接收无效消息！")
                continue
            except Exception as e:
                self.msg_signal.error_msg.emit(f"监听错误：{str(e)}")
                break

    def start_receive_thread(self):
        """补全缺失的方法：启动消息监听线程"""
        self.listen_thread = threading.Thread(target=self.listen_msg, daemon=True)
        self.listen_thread.start()

    def show_error(self, error_text):
        """显示错误提示"""
        if "断开连接" in error_text:
            QMessageBox.critical(self, "错误", error_text)
            self.close()
        else:
            QMessageBox.warning(self, "警告", error_text)

    def show_add_friend_err(self, error_text):
        """显示添加好友错误"""
        QMessageBox.warning(self, "添加好友失败", error_text)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    login_win = LoginWindow()
    login_win.show()
    sys.exit(app.exec_())