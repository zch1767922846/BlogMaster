# 即时通讯系统项目说明文档

## 1. 项目概述

本项目是一个基于Python的即时通讯系统，包含服务器端和客户端两部分。系统支持多用户在线聊天、好友管理、群聊功能以及AI助手交互，采用PyQt5构建客户端GUI界面，使用SQLite进行数据存储，通过Socket实现网络通信。

## 2. 项目结构

```
zch/
├── client.py          # 客户端实现代码
├── server.py          # 服务器端实现代码
├── im_db.db           # SQLite数据库文件
├── readme.md         # 项目说明文档
└── .idea/             # IDE配置文件目录
    ├── misc.xml
    ├── inspectionProfiles/
    ├── modules.xml
    ├── workspace.xml
    └── .gitignore
```

## 3. 技术栈

- **编程语言**：Python 3.10
- **客户端GUI**：PyQt5
- **网络通信**：Socket
- **并发处理**：多线程
- **数据库**：SQLite 3
- **AI集成**：Coze API

## 4. 服务器端功能说明（server.py）

### 4.1 核心功能

- 处理多客户端连接（基于多线程实现）
- 用户注册与登录验证
- 好友关系管理
- 消息转发与离线消息存储
- 群聊创建与消息广播
- 在线状态管理与推送

### 4.2 数据库设计

服务器使用SQLite数据库（im_db.db），包含以下表结构：

1. **用户表（users）**
   - id: 整数，主键自增
   - username: 文本，唯一非空（用户名）
   - password: 文本，非空（密码）

2. **好友表（friends）**
   - user_id: 整数（关联用户表id）
   - friend_id: 整数（关联用户表id）
   - 联合主键：(user_id, friend_id)

3. **离线消息表（offline_msgs）**
   - id: 整数，主键自增
   - sender: 文本，非空（发送者用户名）
   - receiver: 文本，非空（接收者用户名）
   - content: 文本，非空（消息内容）
   - time: 文本，非空（发送时间）

4. **群表（groups）**
   - group_id: 整数，主键自增
   - group_name: 文本，非空（群名称）
   - creator: 文本，非空（创建者用户名）
   - create_time: 文本，非空（创建时间）

5. **群成员表（group_members）**
   - group_id: 整数（关联群表group_id）
   - username: 文本，非空（成员用户名）
   - 联合主键：(group_id, username)

### 4.3 主要类与方法

#### IMServer类

- `__init__`: 初始化服务器，绑定主机和端口，初始化数据库
- `get_friends_by_username`: 根据用户名获取所有好友
- `push_status_update`: 向目标用户的所有好友推送状态更新
- `get_user_groups`: 获取用户加入的所有群
- `broadcast_group_msg`: 广播群消息给群内所有在线成员
- `get_group_name`: 根据群ID获取群名称
- `handle_client`: 处理单个客户端连接（核心方法）

## 5. 客户端功能说明（client.py）

### 5.1 核心功能

- 用户登录界面（隐含功能）
- 主聊天界面（优化UI）
- 好友列表展示与状态显示
- 群聊列表展示
- 消息发送与接收
- 离线消息展示
- AI助手交互
- 好友添加、群聊创建与加入功能

### 5.2 界面设计

主聊天界面采用分割布局，左侧为功能区，右侧为聊天区：

1. **左侧功能区**
   - 好友列表（显示在线/离线状态）
   - 群聊列表
   - AI助手列表
   - 功能按钮（添加好友、创建群聊、加入群聊）

2. **右侧聊天区**
   - 聊天标题栏（显示当前聊天对象）
   - 消息展示区域（只读文本框）
   - 消息输入区域（输入框+发送按钮）

### 5.3 主要类与方法

#### MainWindow类

- `__init__`: 初始化主窗口，设置UI布局和样式
- `toggle_send_button`: 根据输入内容和聊天对象状态切换发送按钮可用性
- `init_ai_client`: 初始化AI客户端（Coze API）
- `init_ai_list`: 初始化AI列表
- 各类事件处理方法：处理好友选择、群聊选择、AI选择、消息发送等操作

## 6. 使用说明

### 6.1 启动方法

1. 首先启动服务器：
   ```bash
   python server.py
   ```

2. 启动客户端（可启动多个实例模拟多用户）：
   ```bash
   python client.py
   ```

### 6.2 测试账号

系统预设测试账号：
- 用户名：user1，密码：123
- 用户名：user2，密码：222
- 用户名：user3，密码：321
- 群聊名：group1

### 6.3 基本操作

1. 登录：使用上述账号登录系统
2. 添加好友：点击"添加好友"按钮，输入目标用户名
3. 发送消息：在左侧选择聊天对象，在输入框输入消息，点击发送或按回车键
4. 创建群聊：点击"创建群聊"按钮，输入群名称
5. 加入群聊：点击"加入群聊"按钮，输入群ID
6. AI聊天：在左侧AI助手列表选择AI进行对话

## 7. 消息协议

系统采用JSON格式进行消息交互，主要消息类型：

1. 注册相关：`register`, `register_result`
2. 登录相关：`login`, `login_result`
3. 单聊消息：`single_msg`
4. 群聊消息：`group_chat_msg`
5. 状态更新：`status_update`
6. 群聊更新：`group_update`
7. AI响应：`ai_response`

## 8. 注意事项

1. 服务器默认绑定本地地址（127.0.0.1）和端口（5555）
2. 数据库文件（im_db.db）会在首次运行服务器时自动创建
3. AI助手功能依赖Coze API，需确保网络连接正常
4. 多用户测试时需启动多个客户端实例