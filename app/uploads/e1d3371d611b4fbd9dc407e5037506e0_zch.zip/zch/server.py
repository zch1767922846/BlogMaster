import socket
import threading
import json
import sqlite3
from datetime import datetime


# 初始化数据库（新增群聊相关表）
def init_db():
    conn = sqlite3.connect('im_db.db')
    c = conn.cursor()
    # 用户表：id、用户名、密码
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL)''')
    # 好友表：用户ID、好友ID（关联用户表）
    c.execute('''CREATE TABLE IF NOT EXISTS friends
                 (user_id INTEGER,
                  friend_id INTEGER,
                  FOREIGN KEY(user_id) REFERENCES users(id),
                  FOREIGN KEY(friend_id) REFERENCES users(id),
                  PRIMARY KEY(user_id, friend_id))''')
    # 离线消息表：发送者、接收者、内容、时间
    c.execute('''CREATE TABLE IF NOT EXISTS offline_msgs
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  sender TEXT NOT NULL,
                  receiver TEXT NOT NULL,
                  content TEXT NOT NULL,
                  time TEXT NOT NULL)''')
    # 新增：群表（群ID、群名称、创建者用户名）
    c.execute('''CREATE TABLE IF NOT EXISTS groups
                 (group_id INTEGER PRIMARY KEY AUTOINCREMENT,
                  group_name TEXT NOT NULL,
                  creator TEXT NOT NULL,
                  create_time TEXT NOT NULL)''')
    # 新增：群成员表（群ID、成员用户名）
    c.execute('''CREATE TABLE IF NOT EXISTS group_members
                 (group_id INTEGER,
                  username TEXT NOT NULL,
                  FOREIGN KEY(group_id) REFERENCES groups(group_id),
                  PRIMARY KEY(group_id, username))''')
    conn.commit()
    conn.close()


class IMServer:
    def __init__(self, host='127.0.0.1', port=5555):
        self.host = host
        self.port = port
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.bind((host, port))
        self.server_socket.listen(5)
        self.online_users = {}  # 在线用户：{用户名: 客户端socket}
        init_db()  # 初始化数据库

    def get_friends_by_username(self, username):
        """根据用户名获取所有好友的用户名（工具函数）"""
        conn = sqlite3.connect('im_db.db')
        c = conn.cursor()
        c.execute("SELECT id FROM users WHERE username=?", (username,))
        user_id = c.fetchone()
        if not user_id:
            conn.close()
            return []
        c.execute("SELECT u.username FROM friends f JOIN users u ON f.friend_id=u.id WHERE f.user_id=?", (user_id[0],))
        friends = [row[0] for row in c.fetchall()]
        conn.close()
        return friends

    def push_status_update(self, target_username, status):
        """向目标用户的所有好友推送状态更新（在线/离线）"""
        friends = self.get_friends_by_username(target_username)
        update_msg = json.dumps({
            "type": "status_update",
            "username": target_username,
            "status": status  # True=在线，False=离线
        }).encode('utf-8')
        # 向每个在线的好友推送
        for friend in friends:
            if friend in self.online_users:
                self.online_users[friend].send(update_msg)

    def get_user_groups(self, username):
        """根据用户名获取加入的所有群（群ID、群名称）"""
        conn = sqlite3.connect('im_db.db')
        c = conn.cursor()
        c.execute('''SELECT g.group_id, g.group_name 
                     FROM groups g JOIN group_members gm ON g.group_id=gm.group_id 
                     WHERE gm.username=?''', (username,))
        groups = [{"group_id": row[0], "group_name": row[1]} for row in c.fetchall()]
        conn.close()
        return groups

    def broadcast_group_msg(self, group_id, sender, content, time_str):
        """广播群消息给群内所有在线成员"""
        conn = sqlite3.connect('im_db.db')
        c = conn.cursor()
        # 查询群内所有成员
        c.execute("SELECT username FROM group_members WHERE group_id=?", (group_id,))
        members = [row[0] for row in c.fetchall()]
        conn.close()
        # 构造群消息
        group_msg = json.dumps({
            "type": "group_chat_msg",
            "group_id": group_id,
            "group_name": self.get_group_name(group_id),  # 获取群名称
            "sender": sender,
            "content": content,
            "time": time_str
        }).encode('utf-8')
        # 推送给所有在线成员（排除发送者）
        for member in members:
            if member != sender and member in self.online_users:
                self.online_users[member].send(group_msg)

    def get_group_name(self, group_id):
        """根据群ID获取群名称"""
        conn = sqlite3.connect('im_db.db')
        c = conn.cursor()
        c.execute("SELECT group_name FROM groups WHERE group_id=?", (group_id,))
        result = c.fetchone()
        conn.close()
        return result[0] if result else "未知群聊"

    def handle_client(self, client_socket, client_addr):
        """处理单个客户端的连接（多线程）- 新增群聊逻辑"""
        print(f"新连接：{client_addr}")
        current_user = None  # 当前连接对应的用户名
        try:
            while True:
                data = client_socket.recv(1024).decode('utf-8')
                if not data:
                    break
                msg = json.loads(data)  # 解析客户端消息（JSON格式）
                msg_type = msg.get('type')

                # 1. 注册请求
                if msg_type == 'register':
                    username, pwd = msg['username'], msg['password']
                    conn = sqlite3.connect('im_db.db')
                    c = conn.cursor()
                    try:
                        c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, pwd))
                        conn.commit()
                        resp = {"type": "register_result", "success": True, "msg": "注册成功"}
                    except sqlite3.IntegrityError:
                        resp = {"type": "register_result", "success": False, "msg": "用户名已存在"}
                    conn.close()
                    client_socket.send(json.dumps(resp).encode('utf-8'))

                # 2. 登录请求（新增：返回用户加入的群列表）
                elif msg_type == 'login':
                    username, pwd = msg['username'], msg['password']
                    conn = sqlite3.connect('im_db.db')
                    c = conn.cursor()
                    c.execute("SELECT id FROM users WHERE username=? AND password=?", (username, pwd))
                    user = c.fetchone()
                    if user:
                        current_user = username
                        self.online_users[username] = client_socket  # 标记为在线

                        # 获取好友列表 + 每个好友的在线状态
                        c.execute("SELECT u.username FROM friends f JOIN users u ON f.friend_id=u.id WHERE f.user_id=?",
                                  (user[0],))
                        friends = [row[0] for row in c.fetchall()]
                        friend_status = {friend: (friend in self.online_users) for friend in friends}

                        # 获取离线消息
                        c.execute("SELECT sender, content, time FROM offline_msgs WHERE receiver=?", (username,))
                        offline_msgs = [{"sender": r[0], "content": r[1], "time": r[2]} for r in c.fetchall()]
                        c.execute("DELETE FROM offline_msgs WHERE receiver=?", (username,))  # 清空离线消息

                        # 新增：获取用户加入的群列表
                        user_groups = self.get_user_groups(username)

                        conn.commit()
                        resp = {
                            "type": "login_result", "success": True, "msg": "登录成功",
                            "friends": friends, "friend_status": friend_status,
                            "offline_msgs": offline_msgs, "user_groups": user_groups  # 新增群列表
                        }

                        # 向当前用户的所有好友推送「上线」通知
                        self.push_status_update(username, status=True)
                    else:
                        resp = {"type": "login_result", "success": False, "msg": "用户名/密码错误"}
                    conn.close()
                    client_socket.send(json.dumps(resp).encode('utf-8'))

                # 3. 单聊消息
                elif msg_type == 'single_msg':
                    sender, receiver, content, time = msg['sender'], msg['receiver'], msg['content'], msg['time']
                    if receiver in self.online_users:
                        # 转发给在线用户
                        self.online_users[receiver].send(json.dumps(msg).encode('utf-8'))
                    else:
                        # 存储离线消息
                        conn = sqlite3.connect('im_db.db')
                        c = conn.cursor()
                        c.execute("INSERT INTO offline_msgs VALUES (NULL, ?, ?, ?, ?)",
                                  (sender, receiver, content, time))
                        conn.commit()
                        conn.close()

                # 4. 群聊消息（新增：广播给群内所有在线成员）
                elif msg_type == 'group_chat_msg':
                    sender = msg['sender']
                    group_id = msg['group_id']
                    content = msg['content']
                    time_str = msg['time']
                    # 验证发送者是否为群成员
                    conn = sqlite3.connect('im_db.db')
                    c = conn.cursor()
                    c.execute("SELECT 1 FROM group_members WHERE group_id=? AND username=?", (group_id, sender))
                    is_member = c.fetchone()
                    conn.close()
                    if is_member:
                        self.broadcast_group_msg(group_id, sender, content, time_str)
                    else:
                        # 非群成员发送失败
                        resp = {"type": "group_msg_result", "success": False, "msg": "你不是该群成员，无法发送消息"}
                        client_socket.send(json.dumps(resp).encode('utf-8'))

                # 5. 添加好友
                elif msg_type == 'add_friend':
                    user = msg['username']
                    friend_name = msg['friend_username'].strip()  # 去除空格，避免匹配失败
                    conn = sqlite3.connect('im_db.db')
                    c = conn.cursor()
                    try:
                        # 1. 查询当前用户ID（确保当前用户存在）
                        c.execute("SELECT id FROM users WHERE username=?", (user,))
                        user_id = c.fetchone()
                        if not user_id:
                            resp = {"type": "add_friend_result", "success": False, "msg": "当前用户不存在"}
                            client_socket.send(json.dumps(resp).encode('utf-8'))
                            conn.close()
                            continue

                        # 2. 查询好友ID（关键：判断好友是否存在）
                        c.execute("SELECT id FROM users WHERE username=?", (friend_name,))
                        friend_id = c.fetchone()
                        if not friend_id:
                            resp = {"type": "add_friend_result", "success": False, "msg": "好友不存在"}
                            client_socket.send(json.dumps(resp).encode('utf-8'))
                            conn.close()
                            continue

                        # 3. 双向添加好友（发起方和接收方都互为好友）
                        c.execute("SELECT 1 FROM friends WHERE user_id=? AND friend_id=?", (user_id[0], friend_id[0]))
                        if c.fetchone():
                            resp = {"type": "add_friend_result", "success": False, "msg": "已是好友，无需重复添加"}
                            client_socket.send(json.dumps(resp).encode('utf-8'))
                            conn.close()
                            continue

                        c.execute("INSERT INTO friends VALUES (?, ?)", (user_id[0], friend_id[0]))
                        c.execute("INSERT INTO friends VALUES (?, ?)", (friend_id[0], user_id[0]))
                        conn.commit()
                        friend_is_online = friend_name in self.online_users
                        resp = {
                            "type": "add_friend_result",
                            "success": True,
                            "msg": "添加好友成功！双方已互为好友",
                            "friend_name": friend_name,
                            "friend_status": friend_is_online
                        }

                        # 向新好友推送当前用户的在线状态
                        if friend_name in self.online_users:
                            push_msg = json.dumps({
                                "type": "status_update",
                                "username": user,
                                "status": (user in self.online_users)
                            }).encode('utf-8')
                            self.online_users[friend_name].send(push_msg)

                    except sqlite3.IntegrityError:
                        resp = {"type": "add_friend_result", "success": False, "msg": "添加失败：已是好友"}
                    except Exception as e:
                        resp = {"type": "add_friend_result", "success": False, "msg": f"添加失败：{str(e)}"}
                        print(f"添加好友服务器错误：{e}")
                    finally:
                        conn.close()
                        client_socket.send(json.dumps(resp).encode('utf-8'))

                # 6. 新增：创建群聊
                elif msg_type == 'create_group':
                    creator = msg['username']
                    group_name = msg['group_name'].strip()
                    if not group_name:
                        resp = {"type": "create_group_result", "success": False, "msg": "群名称不能为空"}
                        client_socket.send(json.dumps(resp).encode('utf-8'))
                        continue

                    conn = sqlite3.connect('im_db.db')
                    c = conn.cursor()
                    try:
                        # 插入群信息
                        create_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                        c.execute("INSERT INTO groups (group_name, creator, create_time) VALUES (?, ?, ?)",
                                  (group_name, creator, create_time))
                        group_id = c.lastrowid  # 获取自动生成的群ID
                        # 插入创建者为群成员
                        c.execute("INSERT INTO group_members VALUES (?, ?)", (group_id, creator))
                        conn.commit()
                        resp = {
                            "type": "create_group_result",
                            "success": True,
                            "msg": f"群聊创建成功！群ID：{group_id}",
                            "group_info": {"group_id": group_id, "group_name": group_name}
                        }
                    except Exception as e:
                        resp = {"type": "create_group_result", "success": False, "msg": f"创建失败：{str(e)}"}
                        print(f"创建群聊错误：{e}")
                    finally:
                        conn.close()
                        client_socket.send(json.dumps(resp).encode('utf-8'))

                # 7. 新增：加入群聊
                elif msg_type == 'join_group':
                    username = msg['username']
                    group_id = msg['group_id']
                    try:
                        group_id = int(group_id)  # 群ID必须是整数
                    except ValueError:
                        resp = {"type": "join_group_result", "success": False, "msg": "群ID必须是数字"}
                        client_socket.send(json.dumps(resp).encode('utf-8'))
                        continue

                    conn = sqlite3.connect('im_db.db')
                    c = conn.cursor()
                    try:
                        # 验证群是否存在
                        c.execute("SELECT group_name FROM groups WHERE group_id=?", (group_id,))
                        group = c.fetchone()
                        if not group:
                            resp = {"type": "join_group_result", "success": False, "msg": "群ID不存在"}
                            client_socket.send(json.dumps(resp).encode('utf-8'))
                            conn.close()
                            continue
                        # 验证是否已加入该群
                        c.execute("SELECT 1 FROM group_members WHERE group_id=? AND username=?", (group_id, username))
                        if c.fetchone():
                            resp = {"type": "join_group_result", "success": False, "msg": "你已加入该群，无需重复加入"}
                            client_socket.send(json.dumps(resp).encode('utf-8'))
                            conn.close()
                            continue
                        # 加入群聊（添加群成员）
                        c.execute("INSERT INTO group_members VALUES (?, ?)", (group_id, username))
                        conn.commit()
                        resp = {
                            "type": "join_group_result",
                            "success": True,
                            "msg": f"成功加入群聊：{group[0]}",
                            "group_info": {"group_id": group_id, "group_name": group[0]}
                        }
                    except Exception as e:
                        resp = {"type": "join_group_result", "success": False, "msg": f"加入失败：{str(e)}"}
                        print(f"加入群聊错误：{e}")
                    finally:
                        conn.close()
                        client_socket.send(json.dumps(resp).encode('utf-8'))

        except Exception as e:
            print(f"处理消息出错：{e}")
        finally:
            # 客户端断开连接：移除在线用户 + 推送「下线」通知
            if current_user in self.online_users:
                del self.online_users[current_user]
                self.push_status_update(current_user, status=False)
            client_socket.close()
            print(f"连接断开：{client_addr}")

    def start(self):
        print(f"服务器启动，监听 {self.host}:{self.port}")
        while True:
            client_sock, addr = self.server_socket.accept()
            threading.Thread(target=self.handle_client, args=(client_sock, addr), daemon=True).start()


if __name__ == '__main__':
    server = IMServer()
    server.start()